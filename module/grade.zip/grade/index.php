<?php
require_once("../../include/initialize.php");

$title   = "Grades";
$header  = "";
$content = 'list.php';

require_once("../../theme/template.php");
?>

<script type="text/javascript">
var gradeTable;
var gradeHistoryTable;

/* Escape text before putting AJAX values into HTML. */
function escapeHtml(value) {
    return $('<div>').text(value == null ? '' : value).html();
}

/*
 * Automatic grading rule:
 * 75 - 99 = Passed
 * 0 - 74.99 = Failed
 *
 * Incomplete and Dropped stay manual.
 */
function calculateRemark(grade, currentRemark) {

    if (currentRemark === 'Incomplete' || currentRemark === 'Dropped') {
        return currentRemark;
    }

    if (grade === '' || grade === null || grade === undefined) {
        return '';
    }

    var number = parseFloat(grade);

    if (isNaN(number) || number < 1 || number > 5) {
        return '';
    }

    return number >= 75 ? 'Passed' : 'Failed';
}

/* Change the remarks whenever a grade is typed. */
function updateRemark(subjectId) {

    var grade = $('input[name="GRADE_VALUE[' + subjectId + ']"]').val();
    var select = $('select[name="GRADE_REMARKS[' + subjectId + ']"]');
    var current = select.val();

    /*
     * If the user is currently using Incomplete/Dropped,
     * keep it. Otherwise calculate Passed/Failed.
     */
    if (current === 'Incomplete' || current === 'Dropped') {
        return;
    }

    var remark = calculateRemark(grade, current);
    select.val(remark);

    updateRemarkStyle(select);
}

function updateRemarkStyle(select) {

    select.removeClass('border-success border-danger border-warning');

    if (select.val() === 'Passed') {
        select.addClass('border-success');
    } else if (select.val() === 'Failed') {
        select.addClass('border-danger');
    } else if (select.val() === 'Incomplete' || select.val() === 'Dropped') {
        select.addClass('border-warning');
    }
}

$(document).ready(function() {

    gradeTable = $('#tblgradestudents').DataTable({
        "processing": true,
        "serverSide": true,
        "scrollX": true,
        "order": [],
        "ajax": {
            url: "<?php echo WEB_ROOT; ?>module/grade/ajax.php",
            type: "POST",
            data: function(d) {
                d.act = 'list';
            }
        },
        "columnDefs": [
            { "orderable": false, "targets": [6] }
        ]
    });

    gradeHistoryTable = $('#tblgradehistory').DataTable({
        "processing": true,
        "serverSide": true,
        "scrollX": true,
        "order": [],
        "ajax": {
            url: "<?php echo WEB_ROOT; ?>module/grade/ajax.php",
            type: "POST",
            data: function(d) {
                d.act = 'history_list';
            }
        },
        "columnDefs": [
            { "orderable": false, "targets": [0, 6, 7, 8] }
        ]
    });
});

/* ============================================================
   OPEN ENCODE GRADES
   ============================================================ */
function openGradeModal(eid) {

    $('#GRADE_SUBJECTS_TBODY').html(
        '<tr><td colspan="3" class="text-muted text-center">Loading...</td></tr>'
    );

    $.ajax({
        url: "<?php echo WEB_ROOT; ?>module/grade/ajax.php",
        method: "POST",
        data: {
            act: 'subjects',
            ENROLLMENT_ID: eid
        },
        dataType: "json",

        success: function(d) {

            if (!d.ENROLLMENT_ID) {
                alert('Could not load that enrollment record.');
                return;
            }

            $('#GRADE_EID').val(d.ENROLLMENT_ID);
            $('#GRADE_IDNO_TEXT').text(d.IDNO || '-');
            $('#GRADE_NAME_TEXT').text(d.FULLNAME || '-');
            $('#GRADE_COURSE_TEXT').text(d.COURSE_TEXT || '-');
            $('#GRADE_TERM_TEXT').text(d.TERM_TEXT || '-');

            $('#GRADE_PICTURE').attr(
                'src',
                d.PICTURE_URL
                    ? d.PICTURE_URL
                    : '<?php echo WEB_ROOT; ?>module/student/image/1.png'
            );

            var rows = '';

            if (!d.subjects || d.subjects.length === 0) {

                rows =
                    '<tr>' +
                    '<td colspan="3" class="text-muted text-center">' +
                    'No subjects taken yet for this enrollment.' +
                    '</td>' +
                    '</tr>';

            } else {

                $.each(d.subjects, function(i, s) {

                    var subjectId = parseInt(s.SUBJECT_ID, 10);
                    var gradeValue =
                        (s.GRADE !== null && s.GRADE !== undefined)
                        ? s.GRADE
                        : '';

                    var savedRemark = s.REMARKS || '';

                    /*
                     * If the saved remark is not Incomplete/Dropped,
                     * calculate Passed/Failed again from the grade.
                     */
                    var remark = calculateRemark(
                        gradeValue,
                        savedRemark
                    );

                    var remarksOptions =
                        '<option value="">-- Remarks --</option>' +
                        '<option value="Passed">Passed</option>' +
                        '<option value="Failed">Failed</option>' +
                        '<option value="Incomplete">Incomplete</option>' +
                        '<option value="Dropped">Dropped</option>';

                    rows +=
                        '<tr>' +

                        '<td>' +
                            escapeHtml(s.SUBJECT_CODE) +
                            '<div class="text-muted small">' +
                                escapeHtml(s.SUBJECT_NAME) +
                            '</div>' +
                        '</td>' +

                        '<td width="25%">' +

                            '<input type="hidden" ' +
                                'name="GRADE_SUBJECT_ID[]" ' +
                                'value="' + subjectId + '">' +

                            '<input type="number" ' +
                                'step="0.01" min="0" ' +
                                'class="form-control form-control-sm grade-input" ' +
                                'name="GRADE_VALUE[' + subjectId + ']" ' +
                                'data-subject-id="' + subjectId + '" ' +
                                'value="' + escapeHtml(gradeValue) + '" ' +
                                'placeholder=" ">' +

                            '<small class="text">' +
                                '75-99 Passed,-74.99 Failed' +
                            '</small>' +

                        '</td>' +

                        '<td width="30%">' +

                            '<select ' +
                                'class="form-control form-control-sm grade-remarks" ' +
                                'name="GRADE_REMARKS[' + subjectId + ']" ' +
                                'data-subject-id="' + subjectId + '">' +

                                remarksOptions +

                            '</select>' +

                            '<small class="text-remark-help">' +
                                'Passed/Failed are automatic. ' +
                                'Incomplete/Dropped can be selected.' +
                            '</small>' +

                        '</td>' +

                        '</tr>';

                    /* Set selected option after HTML is created. */
                    setTimeout(function() {

                        var select = $(
                            'select[name="GRADE_REMARKS[' +
                            subjectId + ']"]'
                        );

                        if (remark) {
                            select.val(remark);
                        } else {
                            select.val('');
                        }

                        updateRemarkStyle(select);

                    }, 0);
                });
            }

            $('#GRADE_SUBJECTS_TBODY').html(rows);

            /*
             * The setTimeout calls above should happen after the table
             * has been inserted. Re-apply saved remarks now for safety.
             */
            if (d.subjects) {
                $.each(d.subjects, function(i, s) {

                    var subjectId = parseInt(s.SUBJECT_ID, 10);
                    var gradeValue =
                        (s.GRADE !== null && s.GRADE !== undefined)
                        ? s.GRADE
                        : '';

                    var savedRemark = s.REMARKS || '';
                    var remark = calculateRemark(gradeValue, savedRemark);

                    var select = $(
                        'select[name="GRADE_REMARKS[' +
                        subjectId + ']"]'
                    );

                    select.val(remark);
                    updateRemarkStyle(select);
                });
            }

            $('#gradeModal').modal('show');
        },

        error: function(xhr) {
            console.log(xhr.responseText);
            alert('Could not load that enrollment record.');
        }
    });
}

$(document).on('click', '.doGrade', function() {
    openGradeModal($(this).attr('EID'));
});

/* ============================================================
   GRADE INPUT -> AUTOMATIC PASSED/FAILED
   ============================================================ */
$(document).on('input', '.grade-input', function() {

    var subjectId = $(this).data('subject-id');
    var select = $(
        'select[name="GRADE_REMARKS[' +
        subjectId + ']"]'
    );

    /*
     * If the user selected Incomplete/Dropped, typing a grade
     * should switch back to automatic Passed/Failed.
     */
    if (select.val() === 'Incomplete' || select.val() === 'Dropped') {
        select.val('');
    }

    updateRemark(subjectId);
});

/* ============================================================
   MANUAL INCOMPLETE / DROPPED
   ============================================================ */
$(document).on('change', '.grade-remarks', function() {

    var value = $(this).val();
    var subjectId = $(this).data('subject-id');
    var grade = $('input[name="GRADE_VALUE[' + subjectId + ']"]').val();

    if (value === 'Incomplete' || value === 'Dropped') {
        updateRemarkStyle($(this));
        return;
    }

    /*
     * User selected blank/Passed/Failed.
     * Passed/Failed is always recalculated from the grade.
     */
    var automatic = calculateRemark(grade, '');
    $(this).val(automatic);
    updateRemarkStyle($(this));
});

/* ============================================================
   VIEW GRADES
   ============================================================ */
$(document).on('click', '.doViewGrade', function() {

    var eid = $(this).attr('EID');

    $('#VG_SUBJECTS_TBODY').html(
        '<tr><td colspan="3" class="text-muted text-center">Loading...</td></tr>'
    );

    $.ajax({
        url: "<?php echo WEB_ROOT; ?>module/grade/ajax.php",
        method: "POST",
        data: {
            act: 'subjects',
            ENROLLMENT_ID: eid
        },
        dataType: "json",

        success: function(d) {

            if (!d.ENROLLMENT_ID) {
                alert('Could not load that enrollment record.');
                return;
            }

            $('#VG_IDNO_TEXT').text(d.IDNO || '-');
            $('#VG_NAME_TEXT').text(d.FULLNAME || '-');
            $('#VG_COURSE_TEXT').text(d.COURSE_TEXT || '-');
            $('#VG_TERM_TEXT').text(d.TERM_TEXT || '-');

            $('#VG_PICTURE').attr(
                'src',
                d.PICTURE_URL
                    ? d.PICTURE_URL
                    : '<?php echo WEB_ROOT; ?>module/student/image/1.png'
            );

            var rows = '';

            if (!d.subjects || d.subjects.length === 0) {

                rows =
                    '<tr><td colspan="3" class="text-muted text-center">' +
                    'No subjects taken yet for this enrollment.' +
                    '</td></tr>';

            } else {

                $.each(d.subjects, function(i, s) {

                    var gradeText =
                        (s.GRADE !== null && s.GRADE !== undefined)
                        ? escapeHtml(s.GRADE)
                        : '<span class="text-muted">Not yet graded</span>';

                    var remark =
                        calculateRemark(
                            s.GRADE,
                            s.REMARKS || ''
                        );

                    var remarksText =
                        remark
                        ? escapeHtml(remark)
                        : '<span class="text-muted">-</span>';

                    rows +=
                        '<tr>' +
                            '<td>' +
                                escapeHtml(s.SUBJECT_CODE) +
                                '<div class="text-muted small">' +
                                    escapeHtml(s.SUBJECT_NAME) +
                                '</div>' +
                            '</td>' +
                            '<td>' + gradeText + '</td>' +
                            '<td>' + remarksText + '</td>' +
                        '</tr>';
                });
            }

            $('#VG_SUBJECTS_TBODY').html(rows);
            $('#viewGradeModal').modal('show');
        },

        error: function(xhr) {
            console.log(xhr.responseText);
            alert('Could not load that enrollment record.');
        }
    });
});

/* ============================================================
   DELETE HISTORY GRADES
   ============================================================ */
$(document).on('click', '.doDeleteGradeHistory', function() {

    var eid = $(this).attr('data-eid');
    var name = $(this).attr('data-name');

    Swal.fire({
        title: 'Delete grade record?',
        text:
            'This will remove the encoded grade(s) for ' +
            (name || 'this student') +
            ' on this past enrollment. This cannot be undone.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete',
        cancelButtonText: 'Cancel'

    }).then((result) => {

        if (result.value) {

            window.location.href =
                "<?php echo WEB_ROOT; ?>" +
                "module/grade/controller.php" +
                "?action=delete_grades&id=" + eid;
        }
    });
});
</script>
